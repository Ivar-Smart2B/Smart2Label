// 
// Epson Label Printer Web SDK Sample Web App
//
// Created by Seiko Epson Corporation on 2021/9/8.
// Copyright (C) 2021 Seiko Epson Corporation. All rights reserved.
// 

const DEBUG = true;

export const debugLog = DEBUG ? console.log.bind(console) : () => { };
