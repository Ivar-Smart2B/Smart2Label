// 
// Epson Label Printer Web SDK Sample Web App
//
// Created by Seiko Epson Corporation on 2021/9/8.
// Copyright (C) 2021 Seiko Epson Corporation. All rights reserved.
// 

export default {
    BACKEND_URL: "",
    API_BASE_PATH:  "api/v1/printers",
    QUEUE_NAME: "-",
};
